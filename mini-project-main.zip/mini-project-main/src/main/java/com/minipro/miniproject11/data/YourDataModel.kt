package com.minipro.miniproject11.data

data class YourDataModel(
    val name: String = "Premendra Engley",
    val password : String = "1234",
    val year: String = "3RD",
    val branch: String = "CSE",
    val attendance: String = "75%",
    val progress : String = "Good",
    val marks :String = "7.10 SGPA"
)
